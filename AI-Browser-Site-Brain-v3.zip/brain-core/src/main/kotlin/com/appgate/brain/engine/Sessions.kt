package com.appgate.brain.engine

import com.appgate.brain.memory.Memory
import com.appgate.brain.model.Goal
import com.appgate.brain.model.ItemVerdict
import com.appgate.brain.model.TaskLedger
import com.appgate.brain.model.TaskResult
import com.appgate.brain.model.TaskStatus
import com.appgate.brain.profile.SiteProfile
import com.appgate.brain.profile.SiteProfiles
import com.appgate.brain.util.Hashing

/** Result of a deep search across several sites, merged and ranked. */
data class SearchOutcome(
    val goal: Goal,
    val perSite: Map<String, TaskLedger>,
    val merged: TaskResult
)

/**
 * Runs one goal over several sites, one after another, on a single renderer. A site that
 * needs a human pauses the whole search until resumed; the ledger for every site survives.
 */
class SearchCoordinator(private val engine: BrainEngine, private val memory: Memory, private val events: EngineEvents) {

    fun newLedgers(goal: Goal, sources: List<SiteProfile>): List<TaskLedger> = sources.map { p ->
        TaskLedger(id = Hashing.short(goal.id + p.key + System.nanoTime()), goal = goal, host = p.hosts.first(), startUrl = p.startUrl).also { memory.saveLedger(it) }
    }

    /** Runs every ledger that is not finished; returns as soon as one needs a human or a grant. */
    fun run(goal: Goal, ledgers: List<TaskLedger>, mode: EngineMode = EngineMode.ASSIST): SearchOutcome {
        for (ledger in ledgers) {
            if (ledger.done) continue
            events.status("Searching ${ledger.host}…")
            val out = engine.runTask(ledger, mode)
            if (out.status == TaskStatus.NEED_HUMAN || out.status == TaskStatus.NEED_GRANT || out.status == TaskStatus.PAUSED) break
        }
        return outcome(goal, ledgers)
    }

    fun outcome(goal: Goal, ledgers: List<TaskLedger>): SearchOutcome = SearchMerge.outcome(goal, ledgers)
}

/** Merges per-site ledgers into one ranked result; pure, so UIs can rebuild results after a restart. */
object SearchMerge {
    fun outcome(goal: Goal, ledgers: List<TaskLedger>): SearchOutcome {
        val all = LinkedHashMap<String, ItemVerdict>()
        val notes = mutableListOf<String>()
        var inspected = 0
        for (l in ledgers) {
            l.verdicts.values.forEach { v -> all[l.host + "|" + v.itemKey] = v }
            inspected += l.itemsInspected
            val status = when (l.status) {
                TaskStatus.DONE -> "done"
                TaskStatus.NEED_HUMAN -> "needs you (${l.humanReason.ifBlank { "sign-in or verification" }})"
                TaskStatus.FAILED -> "could not complete"
                TaskStatus.PENDING -> "not started"
                else -> l.status.name.lowercase()
            }
            notes += "${l.host}: $status, ${l.verdicts.size} listings seen, ${l.itemsInspected} inspected"
        }
        val merged = com.appgate.brain.goal.ConstraintEvaluator.summarize(goal, all.values, inspected, notes, if (ledgers.all { it.done }) "DONE" else "PARTIAL")
        return SearchOutcome(goal, ledgers.associateBy { it.host }, merged)
    }
}

/**
 * Overnight learning: rotate through the training sites, each driven by its curriculum.
 * Rotation happens when the curriculum is complete, three goals in a row are blocked, or the
 * per-site chunk elapses — never on a plateau timer.
 */
class LearningSession(
    private val engine: BrainEngine,
    private val memory: Memory,
    private val events: EngineEvents,
    private val sites: List<SiteProfile> = SiteProfiles.training,
    private val perSiteChunkMs: Long = 20 * 60_000L,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    @Volatile var siteIndex: Int = 0
    @Volatile var stopRequested: Boolean = false
    @Volatile var pausedLedger: TaskLedger? = null

    fun stop() { stopRequested = true; engine.requestStop() }

    /** Runs until stopped or a site needs a human. Returns the ledger that needs attention, or null when stopped. */
    fun run(maxSites: Int = Int.MAX_VALUE): TaskLedger? {
        stopRequested = false
        engine.clearStop()
        var visited = 0
        while (!stopRequested && visited < maxSites) {
            val profile = sites[siteIndex % sites.size]
            val site = memory.site(profile.hosts.first())
            Curriculum.ensure(site)
            if (site.challengesToday >= 3) { events.log("info", "${profile.name}: challenge limit reached today; skipping"); siteIndex++; visited++; continue }
            if (Curriculum.isComplete(site)) { events.status("${profile.name}: curriculum complete (${Curriculum.progress(site)})"); memory.saveSite(site); siteIndex++; visited++; continue }
            val startedAt = clock()
            var ordinal = 0
            var blockedInARow = 0
            events.status("Learning ${profile.name} — ${Curriculum.progress(site)}")
            while (!stopRequested && clock() - startedAt < perSiteChunkMs) {
                val goal = Curriculum.nextGoal(site, profile, ordinal++)
                val ledger = TaskLedger(Hashing.short("learn" + System.nanoTime()), goal, profile.hosts.first(), profile.startUrl)
                val out = engine.runTask(ledger, EngineMode.TRAIN)
                Curriculum.recordAttempt(site, out)
                memory.saveSite(site)
                memory.deleteLedger(out.id)
                when (out.status) {
                    TaskStatus.NEED_HUMAN, TaskStatus.NEED_GRANT -> { pausedLedger = out; return out }
                    TaskStatus.PAUSED -> return null
                    TaskStatus.FAILED -> blockedInARow++
                    else -> blockedInARow = 0
                }
                if (blockedInARow >= 3) { events.log("info", "${profile.name}: three blocked goals; rotating"); break }
                if (Curriculum.isComplete(site)) break
            }
            siteIndex++
            visited++
        }
        return null
    }
}
