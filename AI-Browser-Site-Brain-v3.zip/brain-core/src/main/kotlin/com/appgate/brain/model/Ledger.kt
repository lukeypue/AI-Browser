package com.appgate.brain.model

import com.appgate.brain.json.JsonArray
import com.appgate.brain.json.JsonObject

enum class TaskStatus { PENDING, RUNNING, NEED_HUMAN, NEED_GRANT, DONE, FAILED, ABANDONED, PAUSED }

enum class TaskPhase { START, SEARCH, CONSTRAIN, COLLECT, INSPECT, PREPARE_MESSAGE, PREVIEW, DONE }

/** One recorded step for the task's own history (never long-term memory). */
data class LedgerStep(
    val at: Long,
    val phase: TaskPhase,
    val spsHashBefore: String,
    val action: String,
    val status: VerifyStatus?,
    val evidence: String,
    val source: String                   // skill:<id> | planner | recovery | human
) {
    fun toJson(): JsonObject = JsonObject().put("at", at).put("phase", phase.name).put("sps", spsHashBefore).put("action", action)
        .put("status", status?.name).put("evidence", evidence.take(300)).put("source", source)

    companion object {
        fun fromJson(o: JsonObject) = LedgerStep(
            o.optLong("at"), TaskPhase.values().firstOrNull { it.name == o.optString("phase") } ?: TaskPhase.START,
            o.optString("sps"), o.optString("action"),
            o.optStringOrNull("status")?.let { s -> VerifyStatus.values().firstOrNull { it.name == s } },
            o.optString("evidence"), o.optString("source")
        )
    }
}

/**
 * The task ledger survives renderer death and process death. It is persisted before every
 * action and after every verification, so a crash at any instant loses at most one step.
 */
data class TaskLedger(
    val id: String,
    val goal: Goal,
    val host: String,
    val startUrl: String,
    var status: TaskStatus = TaskStatus.PENDING,
    var phase: TaskPhase = TaskPhase.START,
    var cursor: Int = 0,
    var actions: Int = 0,
    var llmCalls: Int = 0,
    var plannerCallsOnSameState: Int = 0,
    var lastSpsHash: String = "",
    var consecutiveFailures: Int = 0,
    var startedAt: Long = 0L,
    var updatedAt: Long = 0L,
    var lastCheckpointUrl: String = "",
    var humanReason: String = "",
    val steps: MutableList<LedgerStep> = mutableListOf(),
    val visited: MutableSet<String> = linkedSetOf(),
    val verdicts: MutableMap<String, ItemVerdict> = linkedMapOf(),
    val grants: MutableList<Grant> = mutableListOf(),
    val appliedConstraints: MutableSet<String> = linkedSetOf(),
    val notes: MutableList<String> = mutableListOf(),
    var previewText: String = "",
    var previewHash: String = "",
    var currentProgram: List<Step> = emptyList(),
    var programSource: String = "",
    var scrollRoundsWithoutNew: Int = 0,
    var pagesVisited: Int = 0,
    var inspectQueue: MutableList<String> = mutableListOf(),
    val constraintAttempts: MutableMap<String, Int> = linkedMapOf(),
    var usedSearchUrl: Boolean = false,
    var searchAttempts: Int = 0,
    var resultsUrl: String = "",
    var currentItem: String? = null,
    var itemsInspected: Int = 0,
    var plannerFailures: Int = 0,
    var timeouts: Int = 0
) {
    val done: Boolean get() = status == TaskStatus.DONE || status == TaskStatus.FAILED || status == TaskStatus.ABANDONED
    val blocked: Boolean get() = status == TaskStatus.NEED_HUMAN || status == TaskStatus.NEED_GRANT || status == TaskStatus.PAUSED

    fun record(step: LedgerStep) {
        steps += step
        while (steps.size > 400) steps.removeAt(0)
        updatedAt = step.at
    }

    fun note(text: String) {
        if (notes.size < 60) notes += text
    }

    fun toJson(): JsonObject = JsonObject()
        .put("id", id).put("goal", goal.toJson()).put("host", host).put("start_url", startUrl)
        .put("status", status.name).put("phase", phase.name).put("cursor", cursor).put("actions", actions)
        .put("llm", llmCalls).put("planner_same", plannerCallsOnSameState).put("last_sps", lastSpsHash)
        .put("fails", consecutiveFailures).put("started", startedAt).put("updated", updatedAt)
        .put("checkpoint", lastCheckpointUrl).put("human_reason", humanReason)
        .put("steps", JsonArray(steps.map { it.toJson() }))
        .putStrings("visited", visited)
        .put("verdicts", JsonArray(verdicts.values.map { it.toJson() }))
        .put("grants", JsonArray(grants.map { it.toJson() }))
        .putStrings("applied", appliedConstraints)
        .putStrings("notes", notes)
        .put("preview", previewText).put("preview_hash", previewHash)
        .put("program", JsonArray(currentProgram.map { it.toJson() })).put("program_source", programSource)
        .put("scroll_no_new", scrollRoundsWithoutNew).put("pages", pagesVisited)
        .putStrings("inspect_queue", inspectQueue)
        .put("attempts", JsonObject().also { j -> constraintAttempts.forEach { (k, v) -> j.put(k, v) } })
        .put("used_search_url", usedSearchUrl).put("search_attempts", searchAttempts).put("results_url", resultsUrl)
        .put("current_item", currentItem).put("inspected", itemsInspected).put("planner_failures", plannerFailures).put("timeouts", timeouts)

    companion object {
        fun fromJson(o: JsonObject): TaskLedger {
            val ledger = TaskLedger(
                id = o.optString("id"),
                goal = Goal.fromJson(o.optObject("goal") ?: JsonObject()),
                host = o.optString("host"),
                startUrl = o.optString("start_url")
            )
            ledger.status = TaskStatus.values().firstOrNull { it.name == o.optString("status") } ?: TaskStatus.PENDING
            ledger.phase = TaskPhase.values().firstOrNull { it.name == o.optString("phase") } ?: TaskPhase.START
            ledger.cursor = o.optInt("cursor")
            ledger.actions = o.optInt("actions")
            ledger.llmCalls = o.optInt("llm")
            ledger.plannerCallsOnSameState = o.optInt("planner_same")
            ledger.lastSpsHash = o.optString("last_sps")
            ledger.consecutiveFailures = o.optInt("fails")
            ledger.startedAt = o.optLong("started")
            ledger.updatedAt = o.optLong("updated")
            ledger.lastCheckpointUrl = o.optString("checkpoint")
            ledger.humanReason = o.optString("human_reason")
            o.optArray("steps")?.objects()?.forEach { ledger.steps += LedgerStep.fromJson(it) }
            ledger.visited += o.optStrings("visited")
            o.optArray("verdicts")?.objects()?.forEach { v ->
                val verdict = verdictFromJson(v)
                ledger.verdicts[verdict.itemKey] = verdict
            }
            o.optArray("grants")?.objects()?.forEach { g ->
                ledger.grants += Grant(g.optString("id"), g.optString("task"), g.optString("host"), Role.parse(g.optStringOrNull("role")),
                    g.optString("preview"), g.optLong("issued"), g.optLong("ttl", 120_000L), g.optBoolean("used"))
            }
            ledger.appliedConstraints += o.optStrings("applied")
            ledger.notes += o.optStrings("notes")
            ledger.previewText = o.optString("preview")
            ledger.previewHash = o.optString("preview_hash")
            ledger.currentProgram = o.optArray("program")?.objects()?.map { Step.fromJson(it) } ?: emptyList()
            ledger.programSource = o.optString("program_source")
            ledger.scrollRoundsWithoutNew = o.optInt("scroll_no_new")
            ledger.pagesVisited = o.optInt("pages")
            ledger.inspectQueue = o.optStrings("inspect_queue").toMutableList()
            o.optObject("attempts")?.entries()?.forEach { (k, v) -> ledger.constraintAttempts[k] = v.asDoubleOrNull()?.toInt() ?: 0 }
            ledger.usedSearchUrl = o.optBoolean("used_search_url")
            ledger.searchAttempts = o.optInt("search_attempts")
            ledger.resultsUrl = o.optString("results_url")
            ledger.currentItem = o.optStringOrNull("current_item")
            ledger.itemsInspected = o.optInt("inspected")
            ledger.plannerFailures = o.optInt("planner_failures")
            ledger.timeouts = o.optInt("timeouts")
            return ledger
        }

        fun verdictFromJson(v: JsonObject): ItemVerdict = ItemVerdict(
            itemKey = v.optString("key"),
            title = v.optString("title"),
            hrefPath = v.optStringOrNull("path"),
            url = v.optStringOrNull("url"),
            price = if (v.has("price")) v.optInt("price") else null,
            mileage = if (v.has("mileage")) v.optInt("mileage") else null,
            year = if (v.has("year")) v.optInt("year") else null,
            perConstraint = v.optObject("verdicts")?.entries()?.mapNotNull { (k, x) ->
                x.asStringOrNull()?.let { s -> Verdict.values().firstOrNull { it.name == s } }?.let { k to it }
            }?.toMap() ?: emptyMap(),
            evidence = v.optArray("evidence")?.objects()?.map { Evidence(it.optString("key"), it.optString("span"), it.optString("method")) } ?: emptyList(),
            inspectedDetail = v.optBoolean("inspected"),
            softScore = v.optDouble("soft")
        )
    }
}
