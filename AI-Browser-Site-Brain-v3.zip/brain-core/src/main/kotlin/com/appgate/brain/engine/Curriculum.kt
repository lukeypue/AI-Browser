package com.appgate.brain.engine

import com.appgate.brain.model.Budget
import com.appgate.brain.model.Constraint
import com.appgate.brain.model.ConstraintClass
import com.appgate.brain.model.ConstraintOp
import com.appgate.brain.model.ConstraintSource
import com.appgate.brain.model.CurriculumItem
import com.appgate.brain.model.Goal
import com.appgate.brain.model.GoalIntent
import com.appgate.brain.model.SiteModel
import com.appgate.brain.model.TaskLedger
import com.appgate.brain.profile.SiteProfile
import com.appgate.brain.util.Hashing

/**
 * A curriculum replaces rotation timers: each site has an ordered list of goals with
 * completion predicates, and the learner rotates when the curriculum is complete or three
 * goals in a row are blocked. Items are keyed by the skill whose verified success completes them.
 */
object Curriculum {
    private val items = listOf(
        "search" to "Search verifies (query typed, results change)",
        "constrain_numeric" to "A numeric facet (price/mileage/year) applies and verifies",
        "select_facet" to "A choice facet (make/model/condition) applies and verifies",
        "scroll_results" to "Infinite scroll or scrolling reveals new results",
        "next_page" to "Pagination reveals a new page of results",
        "load_more" to "Load-more reveals new results",
        "sort_results" to "Sorting changes result order",
        "open_item" to "A result opens to its detail page",
        "expand_description" to "A truncated description expands",
        "go_back" to "Back returns to results",
        "dismiss_dialog" to "A blocking dialog is dismissed"
    )

    fun ensure(site: SiteModel) {
        val known = site.curriculum.map { it.id }.toSet()
        items.forEach { (id, desc) -> if (id !in known) site.curriculum += CurriculumItem(id, desc) }
    }

    fun markSkillVerified(site: SiteModel, skillId: String, now: Long) {
        ensure(site)
        site.curriculum.firstOrNull { it.id == skillId && !it.done }?.let { it.completedAt = now }
    }

    fun isComplete(site: SiteModel): Boolean {
        ensure(site)
        val core = setOf("search", "open_item")
        val coreDone = site.curriculum.filter { it.id in core }.all { it.done }
        val anyPaginate = site.curriculum.filter { it.id in setOf("scroll_results", "next_page", "load_more") }.any { it.done }
        val anyFacet = site.curriculum.filter { it.id in setOf("constrain_numeric", "select_facet") }.any { it.done }
        return coreDone && anyPaginate && anyFacet
    }

    fun consecutiveBlocked(site: SiteModel): Int = site.curriculum.filter { !it.done }.take(3).count { it.blocked >= 2 }

    /** Next training goal for a site: a small FIND_LISTINGS task whose steps exercise the unfinished items. */
    fun nextGoal(site: SiteModel, profile: SiteProfile, ordinal: Int): Goal {
        ensure(site)
        val queries = profile.trainingQueries.ifEmpty { listOf("mountain bike", "coffee table", "cordless drill") }
        val query = queries[ordinal % queries.size]
        val constraints = mutableListOf<Constraint>()
        val wantNumeric = site.curriculum.firstOrNull { it.id == "constrain_numeric" }?.done != true || ordinal % 2 == 0
        if (wantNumeric) constraints += Constraint("price", ConstraintOp.LTE, listOf("500", "800", "1200", "8000", "15000")[ordinal % 5], sources = setOf(ConstraintSource.FILTERABLE, ConstraintSource.CARD_CHECK))
        if ("vehicles" in profile.categories && ordinal % 3 == 1) constraints += Constraint("mileage", ConstraintOp.LTE, "150000", sources = setOf(ConstraintSource.FILTERABLE, ConstraintSource.CARD_CHECK))
        constraints += Constraint("keyword", ConstraintOp.CONTAINS, query, sources = setOf(ConstraintSource.CARD_CHECK), synonyms = query.lowercase().split(' '))
        val wantDetail = site.curriculum.firstOrNull { it.id == "open_item" }?.done != true || site.curriculum.firstOrNull { it.id == "expand_description" }?.done != true || ordinal % 4 == 3
        val inspect = if (wantDetail) 2 else 0
        if (wantDetail) {
            // A text-evidence constraint forces the detail phase (open item, expand, read, back) to be exercised.
            constraints += Constraint("feature_learn_title", ConstraintOp.CONTAINS, "clean title", cls = ConstraintClass.RARE,
                sources = setOf(ConstraintSource.TEXT_EVIDENCE, ConstraintSource.DETAIL_CHECK), synonyms = listOf("clean title", "title in hand", "salvage title", "rebuilt title", "title"))
        }
        return Goal(
            id = Hashing.short("learn|${site.host}|$ordinal|${System.nanoTime()}"),
            intent = GoalIntent.LEARN_SITE,
            rawText = "learn: $query",
            query = query,
            constraints = constraints,
            budget = Budget(itemsInspected = inspect.coerceAtLeast(1), llmCalls = 4, actions = 40, wallMs = 8 * 60_000L),
            category = profile.categories.firstOrNull()
        )
    }

    fun recordAttempt(site: SiteModel, ledger: TaskLedger) {
        ensure(site)
        val verifiedSkills = ledger.steps.filter { it.status == com.appgate.brain.model.VerifyStatus.VERIFIED && it.source.startsWith("skill:") }.map { it.source.removePrefix("skill:") }.toSet()
        site.curriculum.forEach { item ->
            if (item.done) return@forEach
            item.attempts++
            if (item.id in verifiedSkills) item.completedAt = ledger.updatedAt.takeIf { it > 0 } ?: System.currentTimeMillis()
            else if (ledger.status == com.appgate.brain.model.TaskStatus.NEED_HUMAN || ledger.status == com.appgate.brain.model.TaskStatus.FAILED) item.blocked++
        }
    }

    fun progress(site: SiteModel): String {
        ensure(site)
        val done = site.curriculum.count { it.done }
        return "$done/${site.curriculum.size} curriculum goals verified"
    }
}
