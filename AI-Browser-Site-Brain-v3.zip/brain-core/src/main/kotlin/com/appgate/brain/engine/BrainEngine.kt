package com.appgate.brain.engine

import com.appgate.brain.goal.ConstraintEvaluator
import com.appgate.brain.json.JsonObject
import com.appgate.brain.memory.Episode
import com.appgate.brain.memory.Memory
import com.appgate.brain.model.Action
import com.appgate.brain.model.ActionKind
import com.appgate.brain.model.Binding
import com.appgate.brain.model.ConstraintSource
import com.appgate.brain.model.Goal
import com.appgate.brain.model.GoalIntent
import com.appgate.brain.model.Grant
import com.appgate.brain.model.LedgerStep
import com.appgate.brain.model.PageType
import com.appgate.brain.model.Postcondition
import com.appgate.brain.model.Role
import com.appgate.brain.model.SemanticPageState
import com.appgate.brain.model.SiteModel
import com.appgate.brain.model.Skill
import com.appgate.brain.model.Step
import com.appgate.brain.model.TaskLedger
import com.appgate.brain.model.TaskPhase
import com.appgate.brain.model.TaskResult
import com.appgate.brain.model.TaskStatus
import com.appgate.brain.model.Verdict
import com.appgate.brain.model.VerifyStatus
import com.appgate.brain.perception.SpsParser
import com.appgate.brain.perception.UrlPatterns
import com.appgate.brain.planner.Planner
import com.appgate.brain.planner.PlannerRefused
import com.appgate.brain.profile.SiteProfile
import com.appgate.brain.profile.SiteProfiles
import com.appgate.brain.skills.SkillCompiler
import com.appgate.brain.util.Hashing
import com.appgate.brain.verify.Verifier
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean

interface EngineEvents {
    fun status(text: String) {}
    fun step(ledger: TaskLedger, description: String, status: VerifyStatus?) {}
    fun needHuman(ledger: TaskLedger, reason: String, url: String) {}
    fun needGrant(ledger: TaskLedger, previewText: String, previewHash: String) {}
    fun finished(ledger: TaskLedger, result: TaskResult?) {}
    fun log(level: String, message: String) {}
}

data class EngineConfig(
    val maxTimeouts: Int = 3,
    val plannerCooldownMs: Long = 15_000L,
    val maxPlannerCallsSameState: Int = 2,
    val maxConsecutiveFailures: Int = 6,
    val plannerConfidenceFloor: Double = 0.35,
    val ambiguousRecheckMs: Long = 2_500L,
    val idleSleepMs: Long = 200L,
    val pacingOverrideMs: Long? = null          // tests: 0; production: null (profile pacing)
)

/**
 * The planner/executor/verifier loop over Semantic Page State.
 *
 * One thread runs one task at a time; every renderer call has a deadline; every step is
 * checkpointed to the ledger before it runs and after it is verified. The verifier is the
 * only writer of success/failure into memory; the planner is consulted only on a miss.
 */
class BrainEngine(
    private val renderer: Renderer,
    private val memory: Memory,
    private val plannerFactory: () -> Planner?,
    private val events: EngineEvents,
    private val config: EngineConfig = EngineConfig(),
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val stopRequested = AtomicBoolean(false)
    @Volatile var currentLedger: TaskLedger? = null
        private set
    private var lastPlannerCallAt = 0L

    fun requestStop() { stopRequested.set(true) }
    fun clearStop() { stopRequested.set(false) }

    /** Issue a grant for the ledger's current preview; the next tick may commit. */
    fun grant(ledger: TaskLedger): Grant {
        val g = Grant(Hashing.short("grant" + clock() + ledger.id), ledger.id, ledger.host, Role.SEND, ledger.previewHash, clock())
        ledger.grants += g
        ledger.status = TaskStatus.RUNNING
        memory.saveLedger(ledger)
        return g
    }

    // ------------------------------------------------------------------ public entry points

    fun runTask(ledger: TaskLedger, mode: EngineMode = EngineMode.ASSIST): TaskLedger {
        stopRequested.set(false)
        currentLedger = ledger
        val profile = SiteProfiles.forHost(ledger.host) ?: SiteProfiles.generic(ledger.host)
        val site = memory.site(ledger.host)
        val parserFactory = { SpsParser(site.facetVocabulary + profile.facetVocabulary) }
        val executor = Executor(renderer, parserFactory)
        val policy = TaskPolicy(profile, site)
        val effectiveMode = if (ledger.goal.intent == GoalIntent.LEARN_SITE) EngineMode.TRAIN else mode
        renderer.setNetworkMode(effectiveMode.name, site.endpointEffects.filterValues { it == com.appgate.brain.model.EffectClass.READ }.keys.toList(), site.endpointEffects.filterValues { it == com.appgate.brain.model.EffectClass.COMMIT_EXTERNAL }.keys.toList())

        if (ledger.status == TaskStatus.PENDING) { ledger.startedAt = clock(); }
        ledger.status = TaskStatus.RUNNING
        ledger.humanReason = ""
        memory.saveLedger(ledger)
        events.status("Starting on ${profile.name}: ${ledger.goal.describe()}")

        try {
            // Land on the site (or on the last checkpoint after a resume).
            val current = runCatching { renderer.currentUrl() }.getOrDefault("")
            val currentHost = UrlPatterns.host(current)
            val fresh = ledger.actions == 0 && ledger.lastCheckpointUrl.isBlank()
            val target = when {
                fresh -> ledger.startUrl                                   // a new task always starts from a known page
                ledger.lastCheckpointUrl.isNotBlank() && !UrlPatterns.sameSite(current, ledger.lastCheckpointUrl) -> ledger.lastCheckpointUrl
                currentHost.isBlank() || !UrlPatterns.sameSite("https://$currentHost/", ledger.startUrl) -> ledger.startUrl
                else -> null
            }
            if (target != null) {
                val outcome = executor.execute(Action(ActionKind.NAVIGATE, url = target, expect = emptyList(), effect = com.appgate.brain.model.EffectClass.NAVIGATE), emptySps(ledger.host), effectiveMode, ledger.grants, null, clock())
                if (outcome is ExecOutcome.Failed) { handleRendererFailure(ledger, outcome.reason, outcome.timeout); if (ledger.done) return finish(ledger, site) }
            }

            var consecutiveNoAction = 0
            while (!ledger.done && !ledger.blocked) {
                if (stopRequested.get()) { ledger.status = TaskStatus.PAUSED; ledger.note("paused by user"); memory.saveLedger(ledger); events.status("Paused"); return ledger }
                if (clock() - ledger.startedAt > ledger.goal.budget.wallMs) { ledger.status = TaskStatus.DONE; ledger.note("time budget reached"); break }

                val sps = observeOrRecover(executor, ledger) ?: break
                site.recordPage(sps.pageType, clock())
                trackSiteVersion(site, sps)
                collectCards(ledger, sps)
                ledger.lastSpsHash = sps.hash
                if (sps.pageType != PageType.ERROR && !sps.isHumanOnly) ledger.lastCheckpointUrl = sps.url

                if (sps.isHumanOnly) {
                    if (sps.challenge) site.recordChallenge(clock())
                    memory.saveSite(site)
                    val reason = if (sps.challenge) "This site is asking for a human verification step." else "This site needs you to sign in."
                    ledger.status = TaskStatus.NEED_HUMAN
                    ledger.humanReason = reason
                    memory.saveLedger(ledger)
                    events.needHuman(ledger, reason, sps.url)
                    return ledger
                }

                // Continue an in-flight program before asking the policy again.
                if (ledger.currentProgram.isNotEmpty() && ledger.cursor < ledger.currentProgram.size) {
                    runProgramStep(ledger, sps, site, profile, executor, effectiveMode)
                    consecutiveNoAction = 0
                    continue
                }
                if (ledger.currentProgram.isNotEmpty()) finishProgram(ledger, sps, site, success = true)

                when (val decision = policy.decide(ledger.goal, sps, ledger)) {
                    is PolicyDecision.RunSkill -> {
                        val skill = memory.skills.get(decision.skillId)
                        if (skill == null) { ledger.note("unknown skill ${decision.skillId}"); ledger.consecutiveFailures++; continue }
                        startProgram(ledger, skill.body, decision.params, "skill:${skill.id}", decision.reason)
                        consecutiveNoAction = 0
                    }
                    is PolicyDecision.Navigate -> {
                        startProgram(ledger, listOf(Step(com.appgate.brain.model.StepKind.NAVIGATE, arg = decision.url, expect = listOf(Postcondition.UrlChanged))), emptyMap(), "navigate", decision.reason)
                        consecutiveNoAction = 0
                    }
                    is PolicyDecision.AskPlanner -> {
                        if (!askPlanner(ledger, sps, site, profile, decision.reason)) {
                            if (!exploratoryFallback(ledger, sps)) {
                                ledger.status = if (ledger.verdicts.isNotEmpty()) TaskStatus.DONE else TaskStatus.FAILED
                                ledger.note("stuck: ${decision.reason}")
                            }
                        }
                    }
                    is PolicyDecision.Finish -> { ledger.status = decision.status; ledger.note(decision.reason) }
                    is PolicyDecision.NeedHuman -> {
                        ledger.status = TaskStatus.NEED_HUMAN; ledger.humanReason = decision.reason
                        memory.saveLedger(ledger); events.needHuman(ledger, decision.reason, sps.url); return ledger
                    }
                    is PolicyDecision.Grant -> {
                        ledger.previewHash = Hashing.sha256Hex(ledger.host + "|" + ledger.previewText)
                        ledger.status = TaskStatus.NEED_GRANT
                        memory.saveLedger(ledger); events.needGrant(ledger, ledger.previewText, ledger.previewHash); return ledger
                    }
                    is PolicyDecision.EvaluateDetail -> {
                        evaluateDetail(ledger, sps, decision.itemKey)
                        consecutiveNoAction++
                        if (consecutiveNoAction > 4) { ledger.currentItem = null }
                    }
                }
                if (ledger.consecutiveFailures >= config.maxConsecutiveFailures) {
                    ledger.status = if (ledger.verdicts.isNotEmpty()) TaskStatus.DONE else TaskStatus.FAILED
                    ledger.note("too many consecutive failures")
                }
                memory.saveLedger(ledger)
            }
        } catch (t: InterruptedException) {
            ledger.status = TaskStatus.PAUSED
            memory.saveLedger(ledger)
            return ledger
        } catch (t: Exception) {
            ledger.status = TaskStatus.FAILED
            ledger.note("engine error: ${t.javaClass.simpleName}: ${t.message?.take(160)}")
            events.log("error", "engine error: $t")
        }
        return finish(ledger, site)
    }

    private fun finish(ledger: TaskLedger, site: SiteModel): TaskLedger {
        if (!ledger.done) ledger.status = TaskStatus.DONE
        memory.saveLedger(ledger)
        memory.saveSite(site)
        val result = if (ledger.goal.intent == GoalIntent.FIND_LISTINGS || ledger.goal.intent == GoalIntent.LEARN_SITE) resultFor(ledger) else null
        events.finished(ledger, result)
        currentLedger = null
        return ledger
    }

    fun resultFor(ledger: TaskLedger): TaskResult =
        ConstraintEvaluator.summarize(ledger.goal, ledger.verdicts.values, ledger.itemsInspected, ledger.notes, ledger.status.name)

    // ------------------------------------------------------------------ programs

    private fun startProgram(ledger: TaskLedger, steps: List<Step>, params: Map<String, String>, source: String, reason: String) {
        // Bind parameters now so the persisted program is self-contained.
        ledger.currentProgram = steps.map { s ->
            s.copy(facetKey = s.facetKey?.let { StepGrounder.substitute(it, params) }, arg = s.arg?.let { StepGrounder.substitute(it, params) },
                expect = s.expect.map { bindExpect(it, params) })
        }
        ledger.cursor = 0
        ledger.programSource = source
        ledger.note("$source: $reason")
        events.status(reason)
        memory.saveLedger(ledger)
    }

    private fun bindExpect(p: Postcondition, params: Map<String, String>): Postcondition = when (p) {
        is Postcondition.AnyOf -> Postcondition.AnyOf(p.alternatives.map { bindExpect(it, params) })
        is Postcondition.ConstraintApplied -> Postcondition.ConstraintApplied(StepGrounder.substitute(p.key, params), p.value?.let { StepGrounder.substitute(it, params) })
        is Postcondition.ValueIs -> Postcondition.ValueIs(StepGrounder.substitute(p.facetKey, params), StepGrounder.substitute(p.value, params))
        is Postcondition.UrlQueryHas -> Postcondition.UrlQueryHas(StepGrounder.substitute(p.key, params))
        else -> p
    }

    private fun runProgramStep(ledger: TaskLedger, sps: SemanticPageState, site: SiteModel, profile: SiteProfile, executor: Executor, mode: EngineMode) {
        val step = ledger.currentProgram[ledger.cursor]
        val grounder = StepGrounder(site)
        when (val g = grounder.ground(step, emptyMap(), sps, ledger.visited)) {
            is GroundingOutcome.Skip -> { ledger.cursor++; events.log("debug", "skip ${step.describe()}: ${g.reason}"); memory.saveLedger(ledger) }
            is GroundingOutcome.Missing -> {
                ledger.note("cannot ground ${step.describe()}: ${g.reason}")
                events.step(ledger, "no target for ${step.describe()}", VerifyStatus.FAILED)
                recordFailureMemory(site, sps, step, "no_target")
                finishProgram(ledger, sps, site, success = false)
            }
            is GroundingOutcome.Ready -> executeGrounded(ledger, sps, site, profile, executor, mode, g.grounded, retriesLeft = 2)
        }
    }

    private fun executeGrounded(ledger: TaskLedger, before: SemanticPageState, site: SiteModel, profile: SiteProfile, executor: Executor, mode: EngineMode, grounded: GroundedStep, retriesLeft: Int) {
        val action = grounded.action
        val stepDesc = "${action.describe()} [${ledger.programSource}]"
        ledger.actions++
        memory.saveLedger(ledger)                       // checkpoint before acting
        events.status(stepDesc)
        pace(profile)
        val started = clock()
        when (val outcome = executor.execute(action, before, mode, ledger.grants, ledger.previewHash.takeIf { it.isNotBlank() }, clock())) {
            is ExecOutcome.Blocked -> {
                if (outcome.needGrant) {
                    ledger.previewHash = Hashing.sha256Hex(ledger.host + "|" + ledger.previewText)
                    ledger.status = TaskStatus.NEED_GRANT; memory.saveLedger(ledger)
                    events.needGrant(ledger, ledger.previewText, ledger.previewHash)
                } else {
                    ledger.note("blocked: ${outcome.reason}")
                    events.step(ledger, "$stepDesc blocked: ${outcome.reason}", VerifyStatus.FAILED)
                    finishProgram(ledger, before, site, success = false)
                }
            }
            is ExecOutcome.Failed -> {
                ledger.record(LedgerStep(clock(), ledger.phase, before.hash, stepDesc, VerifyStatus.FAILED, outcome.reason, ledger.programSource))
                events.step(ledger, stepDesc, VerifyStatus.FAILED)
                recordEpisode(site, before, grounded, VerifyStatus.FAILED, before.pageType, clock() - started)
                if (outcome.timeout) handleRendererFailure(ledger, outcome.reason, true)
                else { ledger.consecutiveFailures++; recordFailureMemory(site, before, grounded.step, "exec:" + outcome.reason.take(40)) }
                finishProgram(ledger, before, site, success = false)
            }
            is ExecOutcome.Done -> {
                var after = outcome.after
                var result = Verifier.verify(action, before, after, ledger.visited)
                if (result.status == VerifyStatus.AMBIGUOUS) {
                    Thread.sleep(config.ambiguousRecheckMs)
                    runCatching { executor.observe(clock()) }.getOrNull()?.let { again -> after = again; result = Verifier.verify(action, before, after, ledger.visited) }
                }
                if (result.status == VerifyStatus.HUMAN_NEEDED) {
                    ledger.record(LedgerStep(clock(), ledger.phase, before.hash, stepDesc, VerifyStatus.HUMAN_NEEDED, result.evidence.joinToString("; "), ledger.programSource))
                    ledger.currentProgram = emptyList(); ledger.cursor = 0
                    memory.saveLedger(ledger)
                    return
                }
                val verified = result.status == VerifyStatus.VERIFIED
                ledger.record(LedgerStep(clock(), ledger.phase, before.hash, stepDesc, result.status, result.evidence.joinToString("; ").take(300), ledger.programSource))
                events.step(ledger, stepDesc, result.status)
                recordEpisode(site, before, grounded, result.status, after.pageType, outcome.ms)
                learnFromOutcome(ledger, site, before, after, grounded, verified)
                if (verified) {
                    ledger.consecutiveFailures = 0
                    ledger.cursor++
                    afterVerified(ledger, before, after, grounded, site)
                } else if (grounded.step.optional) {
                    ledger.cursor++            // optional steps may fail silently
                } else if (retriesLeft > 0 && grounded.alternates.isNotEmpty() && after.pageType == before.pageType && !after.dialogOpen) {
                    // Try the next grounding before re-planning.
                    val alt = grounded.alternates.first()
                    val altAction = action.copy(target = action.target?.copy(affordanceId = alt.affordance.id, nameHint = alt.affordance.name, role = alt.affordance.role))
                    events.log("debug", "retrying ${grounded.step.describe()} with alternate '${alt.affordance.name}'")
                    executeGrounded(ledger, after, site, profile, executor, mode, GroundedStep(grounded.step, altAction, alt, grounded.alternates.drop(1), grounded.predictedP * 0.8), retriesLeft - 1)
                    return
                } else {
                    if (grounded.action.kind == ActionKind.SCROLL) ledger.scrollRoundsWithoutNew++   // exploration, not a failure
                    else { ledger.consecutiveFailures++; recordFailureMemory(site, before, grounded.step, "unverified") }
                    finishProgram(ledger, after, site, success = false)
                }
                memory.saveLedger(ledger)
            }
        }
    }

    private fun afterVerified(ledger: TaskLedger, before: SemanticPageState, after: SemanticPageState, grounded: GroundedStep, site: SiteModel) {
        val role = grounded.step.role
        val key = grounded.step.facetKey
        if ((role == Role.FACET || role == Role.FACET_APPLY) && key != null && !key.startsWith("$")) {
            if (after.constraintsActive.containsKey(key) || Verifier.holds(Postcondition.ResultsChanged, grounded.action, before, after, ledger.visited, mutableListOf())) ledger.appliedConstraints += key
        }
        if (role == Role.SEARCH_BOX && grounded.action.submit && after.pageType == PageType.RESULTS) {
            ledger.phase = if (ledger.phase == TaskPhase.START || ledger.phase == TaskPhase.SEARCH) TaskPhase.CONSTRAIN else ledger.phase
            ledger.resultsUrl = after.url
            learnSearchUrl(site, ledger.goal, after.url)
        }
        if (grounded.action.kind == ActionKind.NAVIGATE && ledger.programSource == "navigate" && after.pageType == PageType.RESULTS && ledger.phase == TaskPhase.START) {
            ledger.phase = TaskPhase.CONSTRAIN
            ledger.resultsUrl = after.url
        }
        if (role == Role.SEND && ledger.goal.intent == GoalIntent.PREPARE_MESSAGE) {
            ledger.phase = TaskPhase.DONE
            ledger.note("message sent with grant ${grounded.action.grantId ?: ledger.grants.lastOrNull()?.id ?: ""}")
        }
        if (role == Role.PAGE_NEXT || role == Role.LOAD_MORE || grounded.action.kind == ActionKind.SCROLL) {
            val newKeys = after.resultKeys.count { it !in ledger.visited }
            ledger.scrollRoundsWithoutNew = if (newKeys > 0) 0 else ledger.scrollRoundsWithoutNew + 1
        }
        collectCards(ledger, after)
    }

    private fun finishProgram(ledger: TaskLedger, sps: SemanticPageState, site: SiteModel, success: Boolean) {
        val source = ledger.programSource
        if (source.startsWith("skill:")) {
            val id = source.removePrefix("skill:")
            memory.skills.recordOutcome(id, ledger.host, success)
            if (success) Curriculum.markSkillVerified(site, id, clock())
        } else if (source == "planner" && success) {
            SkillCompiler.compileFromPlanner(memory, ledger, ledger.currentProgram, clock())
        }
        if (!success && source == "planner") ledger.plannerFailures++
        ledger.currentProgram = emptyList()
        ledger.cursor = 0
        ledger.programSource = ""
        memory.saveLedger(ledger)
        memory.saveSite(site)
    }

    // ------------------------------------------------------------------ learning

    private fun learnFromOutcome(ledger: TaskLedger, site: SiteModel, before: SemanticPageState, after: SemanticPageState, grounded: GroundedStep, verified: Boolean) {
        val chosen = grounded.chosen ?: return
        val role = grounded.step.role ?: return
        val facet = grounded.step.facetKey?.takeIf { !it.startsWith("$") }
        val binding = Binding(
            host = site.host, pageType = before.pageType, role = role, facetKey = facet, siteVersion = before.siteVersion,
            features = chosen.affordance.features, nameHints = listOf(chosen.affordance.name).filter { it.isNotBlank() },
            stats = com.appgate.brain.model.BetaStat(), lastVerifiedAt = 0L
        )
        memory.recordBinding(site.host, binding, verified)
        site.recordEdge(before.pageType, role, facet, after.pageType, verified, clock())
        site.recordCalibration(grounded.predictedP, verified)
        if (verified) site.verifiedActions++ else site.failedActions++
        memory.saveSite(site)
    }

    private fun recordFailureMemory(site: SiteModel, sps: SemanticPageState, step: Step, reason: String) {
        val role = step.role ?: return
        site.recordFailure(sps.pageType, role, step.facetKey?.takeIf { !it.startsWith("$") }, reason, clock())
        memory.saveSite(site)
    }

    private fun recordEpisode(site: SiteModel, before: SemanticPageState, grounded: GroundedStep, status: VerifyStatus, toPage: PageType, ms: Long) {
        memory.recordEpisode(Episode(clock(), site.host, before.pageType, grounded.step.role, grounded.step.facetKey?.takeIf { !it.startsWith("$") },
            grounded.action.kind.name, status, grounded.predictedP, toPage, ms, "engine"))
    }

    private fun trackSiteVersion(site: SiteModel, sps: SemanticPageState) {
        if (sps.siteVersion.isBlank()) return
        if (site.siteVersion.isBlank()) { site.siteVersion = sps.siteVersion; site.versionChangedAt = clock(); return }
        if (site.siteVersion != sps.siteVersion) {
            // A redesign (or A/B test) — shadow, never delete.
            site.bindings.replaceAll { _, b -> if (b.siteVersion.isNotBlank() && b.siteVersion != sps.siteVersion) b.copy(shadowed = true) else b }
            site.siteVersion = sps.siteVersion
            site.versionChangedAt = clock()
            events.log("info", "site version changed on ${site.host}; old bindings shadowed")
        }
    }

    /** Learn a direct search URL template from a verified search (query encoded in the URL). */
    private fun learnSearchUrl(site: SiteModel, goal: Goal, url: String) {
        if (goal.query.isBlank()) return
        val encoded = URLEncoder.encode(goal.query, "UTF-8")
        val variants = listOf(encoded, encoded.replace("+", "%20"), encoded.replace("+", "-"), goal.query.replace(' ', '+'), goal.query.replace(' ', '-'))
        for (v in variants) {
            if (url.contains(v, ignoreCase = true)) {
                val template = url.replace(v, "{q}", ignoreCase = true).substringBefore('#')
                if (template.contains("{q}")) {
                    site.searchUrlTemplate = template
                    memory.saveSite(site)
                    return
                }
            }
        }
    }

    // ------------------------------------------------------------------ cards & detail

    private fun collectCards(ledger: TaskLedger, sps: SemanticPageState) {
        val items = sps.results?.items ?: return
        if (sps.pageType != PageType.RESULTS) return
        if (ledger.phase == TaskPhase.START || ledger.phase == TaskPhase.SEARCH) {
            // Only collect once we believe the results reflect the query.
            if (!TaskPolicy(SiteProfiles.forHost(ledger.host) ?: SiteProfiles.generic(ledger.host), memory.site(ledger.host)).queryApplied(ledger.goal, sps)) return
        }
        var added = 0
        for (item in items) {
            if (ledger.verdicts.containsKey(item.key)) continue
            ledger.verdicts[item.key] = ConstraintEvaluator.fromCard(ledger.goal, item, sps.host)
            ledger.visited += item.key
            added++
        }
        if (added > 0) events.log("debug", "collected $added cards (${ledger.verdicts.size} total)")
    }

    private fun evaluateDetail(ledger: TaskLedger, sps: SemanticPageState, itemKey: String) {
        val v = ledger.verdicts[itemKey] ?: run { ledger.currentItem = null; return }
        var updated = ConstraintEvaluator.withDetail(ledger.goal, v, sps.detailText, sps.url)
        val planner = plannerFactory()
        for (c in ledger.goal.rare) {
            if (updated.perConstraint[c.key] == Verdict.UNKNOWN && planner != null && ledger.llmCalls < ledger.goal.budget.llmCalls && sps.detailText.length > 80) {
                ledger.llmCalls++
                val ev = runCatching { planner.extractEvidence(c, sps.detailText, sps.title) }.getOrNull()
                if (ev != null && ev.verdict != Verdict.UNKNOWN && ev.confidence >= 0.6) {
                    updated = updated.copy(
                        perConstraint = updated.perConstraint + (c.key to ev.verdict),
                        evidence = updated.evidence + com.appgate.brain.model.Evidence(c.key, ev.quote, "model")
                    )
                }
            }
        }
        ledger.verdicts[itemKey] = updated
        ledger.itemsInspected++
        ledger.inspectQueue.remove(itemKey)
        ledger.currentItem = null
        ledger.record(LedgerStep(clock(), ledger.phase, sps.hash, "inspect listing", VerifyStatus.VERIFIED, updated.perConstraint.entries.joinToString(", ") { "${it.key}=${it.value}" }, "evaluator"))
        events.step(ledger, "inspected a listing: " + updated.perConstraint.entries.joinToString(", ") { "${it.key}=${it.value.name.lowercase()}" }, VerifyStatus.VERIFIED)
        memory.saveLedger(ledger)
    }

    // ------------------------------------------------------------------ planner

    private fun askPlanner(ledger: TaskLedger, sps: SemanticPageState, site: SiteModel, profile: SiteProfile, reason: String): Boolean {
        val planner = plannerFactory() ?: run { events.log("info", "planner unavailable: $reason"); return false }
        if (ledger.llmCalls >= ledger.goal.budget.llmCalls) { ledger.note("planner budget exhausted"); return false }
        if (ledger.lastSpsHash == sps.hash && ledger.plannerCallsOnSameState >= config.maxPlannerCallsSameState) { ledger.note("planner already tried this state twice"); return false }
        if (clock() - lastPlannerCallAt < config.plannerCooldownMs) Thread.sleep((config.plannerCooldownMs - (clock() - lastPlannerCallAt)).coerceAtLeast(0L))
        lastPlannerCallAt = clock()
        ledger.llmCalls++
        ledger.plannerCallsOnSameState = if (ledger.lastSpsHash == sps.hash) ledger.plannerCallsOnSameState + 1 else 1
        events.status("Thinking about this page…")
        val failuresHere = site.failures.values.filter { it.pageType == sps.pageType }.sortedByDescending { it.lastAt }.take(3).map { "${it.role}${it.facetKey?.let { k -> "[$k]" } ?: ""}: ${it.reason}" }
        val program = try {
            planner.proposeProgram(ledger.goal, sps, ledger, memory.skills.retrieve(reason + " " + ledger.goal.intent.name), failuresHere, profile.quirks)
        } catch (e: PlannerRefused) {
            events.log("warn", "planner refused: ${e.message}"); return false
        } catch (e: Exception) {
            events.log("warn", "planner error: ${e.javaClass.simpleName}: ${e.message?.take(120)}"); ledger.plannerFailures++; return false
        }
        if (program.vocabulary.isNotEmpty()) { site.facetVocabulary.putAll(program.vocabulary); memory.saveSite(site) }
        memory.recordPlannerLabel(site.host, JsonObject().put("page", sps.pageType.name).put("reason", reason.take(80)).put("steps", program.steps.size).put("conf", program.confidence).put("at", clock()))
        if (program.needsHuman != null) { ledger.status = TaskStatus.NEED_HUMAN; ledger.humanReason = program.needsHuman; memory.saveLedger(ledger); events.needHuman(ledger, program.needsHuman, sps.url); return true }
        if (program.giveUp || program.steps.isEmpty() || program.confidence < config.plannerConfidenceFloor) { ledger.note("planner: ${program.rationale}"); return false }
        startProgram(ledger, program.steps, emptyMap(), "planner", program.rationale.ifBlank { "planner program" })
        return true
    }

    /** Cheap exploration when no planner is available: scroll, close dialogs, or return to results. */
    private fun exploratoryFallback(ledger: TaskLedger, sps: SemanticPageState): Boolean {
        if ((ledger.constraintAttempts["__explore"] ?: 0) >= 3) return false
        ledger.constraintAttempts["__explore"] = (ledger.constraintAttempts["__explore"] ?: 0) + 1
        return when {
            sps.dialogOpen && sps.has(Role.CLOSE) -> { startProgram(ledger, memory.skills.get("dismiss_dialog")!!.body, emptyMap(), "skill:dismiss_dialog", "explore: close dialog"); true }
            ledger.resultsUrl.isNotBlank() && sps.url != ledger.resultsUrl -> { startProgram(ledger, listOf(Step(com.appgate.brain.model.StepKind.NAVIGATE, arg = ledger.resultsUrl, expect = listOf(Postcondition.UrlChanged))), emptyMap(), "navigate", "explore: back to results"); true }
            sps.pageType == PageType.RESULTS -> { startProgram(ledger, memory.skills.get("scroll_results")!!.body, emptyMap(), "skill:scroll_results", "explore: scroll"); true }
            else -> false
        }
    }

    // ------------------------------------------------------------------ renderer health

    private fun observeOrRecover(executor: Executor, ledger: TaskLedger): SemanticPageState? {
        repeat(2) { attempt ->
            try {
                return executor.observe(clock())
            } catch (t: RendererTimeout) {
                handleRendererFailure(ledger, "observe timeout", true)
            } catch (t: RendererGone) {
                handleRendererFailure(ledger, "renderer gone", true)
            } catch (t: Exception) {
                ledger.note("observe error: ${t.message?.take(100)}")
                events.log("warn", "observe error: $t")
                Thread.sleep(800)
            }
            if (ledger.done) return null
        }
        ledger.status = TaskStatus.FAILED
        ledger.note("renderer unresponsive")
        return null
    }

    private fun handleRendererFailure(ledger: TaskLedger, reason: String, timeout: Boolean) {
        ledger.timeouts++
        ledger.note("renderer failure: $reason")
        events.log("warn", "renderer failure ($reason); recovering")
        if (ledger.timeouts > config.maxTimeouts) { ledger.status = TaskStatus.FAILED; return }
        runCatching { renderer.recover() }
        Thread.sleep(700)
        val target = ledger.lastCheckpointUrl.ifBlank { ledger.startUrl }
        runCatching { renderer.navigate(target, 20_000L); renderer.waitSettle(10_000L) }
    }

    private fun pace(profile: SiteProfile) {
        val base = config.pacingOverrideMs ?: profile.minActionIntervalMs
        if (base <= 0L) return
        val jitter = (Math.random() * 400).toLong()
        Thread.sleep(base + jitter)
    }

    private fun emptySps(host: String) = SemanticPageState(host, "", "", "", PageType.UNKNOWN, 0.0, emptyList(), emptyList(), emptyList(), emptyMap(), com.appgate.brain.model.Settle.UNKNOWN, false, false, false, "")
}
